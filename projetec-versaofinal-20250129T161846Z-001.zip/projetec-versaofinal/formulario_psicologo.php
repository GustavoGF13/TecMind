<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Formulário Personalizado</title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" type="text/css" href="pagina.css">
    <title>TecMind</title>
</head>

<body id="cor">


    <body>
    <header class="back_fundo">

        
<a href="TecMind.php">
    <img src="img/logo.png" alt="" class="logo">
</a>
<div class="nome_site">
    <h1 id="tecmind">Tec<span class="cor_blog">Mind</span> </h1>

</div>

<ul>
    <a href="TecMind.php" target="_self">
         <li class="option">Início</li>
    </a>
   
    <a href="quemsomos.html" target="_self">
        <li class="option">Quem somos? </li>
    </a>
    <a href="obrigado.html" target="_self">
        <li class="option">Fale Conosco</li>
    </a>

    <a href="login.php" target="_self">
        <img src="img/icons.png" alt="" class="icons"> &nbsp;
    </a>
</ul>

</header>
        <div id="area">
            <!--
            Esse código tem que mudar !!php!! -->

            <form action="processa_cadastropsi.php" method='POST' id="formulario" autocomplete="off">
                <fieldset class="formpsi">
                    <h1 class="colorcd">Cadastro </h1>

                    <hr class="linha">
                    

                   <b><p class="color">Nome:</p></b>
                    <input name="nome" class="campo_nome1" type="text" required="required">
                    <hr class="linha"> 


                    <b><p class="color">CRP:</p></b>
                    <input type="text" minlength="5" maxlength="5" name="crp" class="crp" required="required">
                        <hr class="linha">

                    <b><p class="color">Email:</p> </b>
                    <input name="email" class="campo_email1" class="border" type="text" required="required">
                        <hr class="linha"> 

                    <b><p class="color">Senha:</p></b>
                    <input name="senha" class="campo_senha1" type="password" required="required">
                    <hr class="linha">

                    <b><p class="color">Sexo:</p></b><input type="radio" name="sexo" value="feminino" required="required" checked=" ">Feminino
                    <input type="radio" name="sexo" value="masculino" required="required" checked=" ">Masculino<br>
                    
                    <hr class="linha">

                    <!--Criar uma parte para o tipo de consulta -->
                    
                    <b><p class="color">Tipo de consulta:</p></b>
                    <input type="radio" name="consulta" value="online" required="required" checked=" ">Online   
                    <input type="radio" name="consulta" value="presencial" required="required" checked=" ">Presencial<br>
                    <hr class="linha">
                    
                    <b><p class="color">Abordagem:</p></b>
                    <input class="campo_abrd1" name="abordagem" list="lista-abordagem">
                    <datalist id="lista-abordagem">
                        <option value="Análise bioenergética">
                        <option value="Behavorismo">
                        <option value="Terapia Cognitivo Comportamental">
                        <option value="Psicanálise">
                        <option value="Psicodinâmica">
                        <option value="Psicologia Analítica Junguiana">
                        <option value="Gestalt-Terapia">
                        <option value="Psicodrama">
                        <option value="Fenomenologia">
                        <option value="Abordagem centrada na pessoa">
                    </datalist>
                    <hr class="linha">

                    <b>Meu Endereço:</b> <br>

                    <b><p class="color">Rua:</p></b>
                    <input name="rua" class="campo_rua1" required="required">

                    <b><p class="color">Bairro:</p></b>
                    <input name="bairro" class="campo_bairro1" required="required">

                    <b><p class="color">Número:</p></b>
                    <input name="numero" class="campo_numero1" required="required">
                    
                    <hr class="linha">
                    

                    <b><p class="color"> Sua foto aqui: </p></b> 
                    <div id="foto_do_psi"> 

                        <input type="file" name="foto" id="arquivo" required="required"><br>
                        
                    </div>
                        <button class="botao" class="btn_submit"  type="submit" value="Entrar" >Cadastrar</button>

                    

                </fieldset>

            </form>

            
        </div>

    
        <footer class="corrd">
    <div class="corrd_copy1">
        <p>TecMind 2024 -

           <!-- link instagram-->
            <a href="https://www.instagram.com/_tecmind/">    
             <img  id="insta" src="img/insta.png" alt="">
            </a>
        </p>    

    </div>
</footer>



    </body>
   

</body>
 
</html>