<?php

$conexao = mysqli_connect("localhost","root", "","projetec") or die(mysqli_errno($conexao));

?>