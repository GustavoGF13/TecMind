<?php
$servidor = "localhost";
$usuario = "root";
$senhaser = "";
$bd = "projetec"; 

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $email = filter_var($_POST["email"], FILTER_VALIDATE_EMAIL);
    $senha = $_POST["senha"];
    $cpf = $_POST["cpf"];
    $sexo = $_POST["sexo"];
    $dtnasc = $_POST["dtnasc"];
    $cidade = $_POST["cidade"];

    $sql = "INSERT INTO usuario (CPF, Nome, Sexo, Email, Senha, DtNasc, Cidade) VALUES ('$cpf', '$nome', '$sexo', '$email', '$senha', '$dtnasc', '$cidade')";

    if ($conn->query($sql) === TRUE) {
        header("Location: login.php"); // Redireciona para a página de login
        exit();
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }
}

header(location: "http://localhost/projetec/login.php");
$conn->close();

?>
