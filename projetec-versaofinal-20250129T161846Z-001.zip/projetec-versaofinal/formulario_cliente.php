<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Formulário Personalizado</title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" type="text/css" href="pagina.css">
    <title>TecMind</title>
    <link rel="stylesheet" type="text" href="login.php">
</head>

<body id="cor">



    <body>
    <header class="back_fundo">

        
<a href="TecMind.php">
    <img src="img/logo.png" alt="" class="logo">
</a>
<div class="nome_site">
    <h1 id="tecmind">Tec<span class="cor_blog">Mind</span> </h1>

</div>

<ul>
    <a href="TecMind.php" target="_self">
         <li class="option">Início</li>
    </a>
   
    <a href="quemsomos.html" target="_self">
        <li class="option">Quem somos? </li>
    </a>
    <a href="obrigado.html" target="_self">
        <li class="option">Fale Conosco</li>
    </a>

    <a href="login.php" target="_self">
        <img src="img/icons.png" alt="" class="icons"> &nbsp;
    </a>
</ul>

</header>
        <div id="area">
            <!--
            Esse código tem que mudar !!php!! -->

            <form class="Cadastro" action="processa_cadastrocli.php" method="POST" id="formulario" autocomplete="off">
                <fieldset class="formcli">
                    <h1 class="colorcd">Cadastro </h1>


                    <b><p class="color">Nome:</p></b>
                    <input class="campo_nome" name="nome" type="text" required="required">
                    <hr class="linha"> 

                    <b><p class="color">CPF:</p></b>
                    <input class="campo_nome"  minlength="11" maxlength="11" name="cpf"  type="text" required="required">
                    <hr class="linha"> 

                    <b><p class="color">Sexo:</p></b>
                    <input type="radio" name="sexo" value="feminino" required="required" checked=" ">Feminino<br>
                    <input type="radio" name="sexo" value="masculino" required="required" checked=" ">Masculino<br>
                    
                    <hr class="linha"> 


                    <b><p class="color">Data de Nascimento:<br> ex.: 20/06/2000</p></b>
                    &nbsp;<input class="campo_idade"  minlength="10" maxlength="10" type="text" name="dtnasc" required="required">
                    <hr class="linha"> 

                    <b>Meu Endereço:</b> <br>

                    <b><p class="color">Cidade:</p></b>
                    <input list="list-cidade" class="campo_cidade"  name="cidade"/> 

                    <datalist id="list-cidade">

                        <option value="Sabará-MG"></option>
                        <option value="Belo Horizonte-MG"></option>
                        
                    </datalist>
                    <hr class="linha"> 

        

                    
                    <b><p class="color">Email:</p></b>
                    <input class="campo_email" name="email" type="text"
                        required="required">
                        <hr class="linha"> 

                    <b><p class="color">Senha:</p></b>
                    <input class="campo_senha" name="senha" type="password"
                        required="required">
                        <hr class="linha"> 


                    <button class="botao" class="btn_submit" type="submit" value="Cadastrar" >Cadastrar</button>

                </fieldset>
            </form>

           
        </div>
    </body>
    
    <footer class="corrd">
    <div class="corrd_copy4">
        <p>TecMind 2024 -

           <!-- link instagram-->
            <a href="https://www.instagram.com/_tecmind/">    
             <img  id="insta" src="img/insta.png" alt="">
            </a>
        </p>    

    </div>
</footer>
</body>

</html>