<!DOCTYPE html>
<html lang="pt-br">

<body>

  <head>

    <meta charset="utf-8">

    <meta http-equiv="content-language" content="pt-br" />
    <meta name="robots" content="index, follow" />

    <link rel="stylesheet" type="text/css" href="css/reset.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

  
    
    
  
    <header class="main_header container">
      <div class="content">

        <div class="main_header_logo">

          <a href="TecMind.php">
            <img src="img/logo.png"  alt="logo.png" />
          </a>
          
   
        </div>

      </div>
    </header>


    <main class="main_content container">

      <section class="boxLogin container">
        <div class="content">

          <form action="login.php" class="login" method="post" name="login">

            <h1><i class="icon icon-key-1"></i> Login</h1>

            <div class="padding">

              <label>
                <input type="text" class="campos" placeholder="E-mail" name="email" required="required">
              </label>

              <label>
                <input type="password" class="campos" placeholder="Senha" name="senha" required="required">
              </label>
      
              <input type="submit" class="btn fade_8S" name="entrar" value="Entrar">
              


            </div>

            <div class="linksForm">
              <a href="formulario_cliente.php" class="fade_4S" title="Cadastrar-se"><i class="icon icon-user-add"></i>
                Cadastro Cliente</a>

              <a href="formulario_psicologo.php" class="fade_4S" title="Cadastrar-se"><i class="icon icon-user-add"></i>
                Cadastro Psicólogo</a>

              <?php
                include_once("processa_login.php");
              ?>


            </div>

          </form>


        </div>
      </section>


    </main>

    <footer class="main_footer container">
      <div class="main_footer_copy">

        <p class="m-b-footer"> TecMind 2024. - 
           <!-- link instagram--> 

          <a href="https://www.instagram.com/_tecmind/">    
            <img  id="insta" src="img/insta.png" alt="">   
          </a>

        </p> 

      </div>

    </footer>

    <script src="js/jquery.js"></script>
    <script src="js/script.js"></script>
  </head>

  
</body>

</html>