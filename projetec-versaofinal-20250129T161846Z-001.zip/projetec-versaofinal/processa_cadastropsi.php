<?php
$servidor = "localhost";
$usuario = "root";
$senhaser = "";
$bd = "projetec"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $email = filter_var($_POST["email"], FILTER_VALIDATE_EMAIL);
    $senha = $_POST["senha"];
    $crp = $_POST["crp"];
    $sexo = $_POST["sexo"];
    $consulta = $_POST["consulta"];
    $abordagem = $_POST["abordagem"];
    $rua = $_POST["rua"];
    $bairro = $_POST["bairro"];
    $numero = $_POST["numero"];
    $foto = $_POST["foto"];

    $sql = "INSERT INTO profissional (CRP, Nome, Email, Senha, Sexo, Abordagem, Rua, Numero, Bairro, Consulta, Foto) VALUES ('$crp', '$nome', '$email', '$senha', '$sexo', '$abordagem', '$rua','$numero','$bairro','$consulta', '$foto')";

    if ($conn->query($sql) === TRUE) {
        header("Location: login.php"); 
        exit();
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
