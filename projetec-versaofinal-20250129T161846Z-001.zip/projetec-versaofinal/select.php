<?php
include_once("conexaobd.php");

$sql = "SELECT * FROM profissional";

$resposta = mysqli_query($conexao, $sql) or die ("ERRO ao pesquisar dados do psicologo." . mysqli_error());

$total = mysqli_num_rows($resposta);
echo "<H3> O total de profissionais é: $total .</H3>";

echo "<TABLE border=1>";
echo "<TR><TD>CRP</TD><TD>Nome</TD><TD>Email</TD>
<TD>Sexo</TD><TD>Abordagem</TD><TD>DtNasc</TD><TD>Rua</TD>
<TD>Numero</TD><TD>Bairro</TD>";

while ($registro = mysqli_fetch_assoc($resposta)){
    $crp = $registro['CRP'];
    $nome = $registro['Nome'];
    $email = $registro['Email'];
    $sexo = $registro['Sexo'];
    $abordagem = $registro['Abordagem'];
    $dtnasc = $registro['DtNasc'];
    $rua = $registro['Rua'];
    $numero = $registro['Numero'];
    $bairro = $registro['Bairro'];

    echo "<TR><TD>$crp</TD><TD>$nome</TD><TD>$email</TD>
<TD>$sexo</TD><TD>$abordagem</TD><TD>$dtnasc</TD><TD>$rua</TD>
<TD>$numero</TD><TD>$bairro</TD>";
}
echo "</TABLE";

?>
