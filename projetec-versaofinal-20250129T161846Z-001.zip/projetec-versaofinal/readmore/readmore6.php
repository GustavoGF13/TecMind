<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../pagina.css">
    <link rel="stylesheet" href="../paginicial.css">
    
    <title>Document</title>
</head>
<body>

    <style>
        .rating {
            display: inline-flex;
            flex-direction: row-reverse;
            justify-content: center;
        }

        .rating input {
            display: none;
        }

        .rating label {
            font-size: 2rem;
            color: #ddd;
            cursor: pointer;
            transition: color 0.3s;
        }

        .rating input:checked ~ label,
        .rating input:hover ~ label,
        .rating label:hover ~ label {
            color: #f5b301;
        }

        .rating input:checked + label:hover,
        .rating input:checked ~ label:hover ~ label {
            color: #f7d45f;
        }
    </style>

    
<header class="back_fundo">

<a href="../TecMind.php">
       <img src="../img/logo.png" alt="" class="logo">
   </a>
   <div class="nome_site">
       <h1 id="tecmind">Tec<span class="cor_blog">Mind</span> </h1>

   </div>

   <ul>
      
       <a href="../quemsomos.html" target="_self">
           <li class="option">Quem somos? </li>
       </a>
       <a href="../obrigado.html" target="_self">
           <li class="option">Fale Conosco</li>
       </a>

       <a href="../login.php" target="_self">
           <img src="../img/icons.png" alt="" class="icons"> &nbsp;
       </a>
   </ul>

</header>

    <div>
        <img class="imgrm" src="../img/foto6.png">
    </div>

    <div class="rm_box">
            <h1 class="rm_h1">&nbsp; &nbsp; &nbsp;Dr. Pedro Junior</h1>
            &nbsp; &nbsp; &nbsp;Sou o doutor Pedro Junior, psicólogo com foco em fenomenologia e especialização em neuropsicologia em adultos.<br><br> 
            &nbsp; &nbsp; &nbsp;<b>Atendimentos:</b> presenciais e online.<br>
            &nbsp; &nbsp; &nbsp;<b>Telefone de contato:</b> (31) 98596-1658<br>
            &nbsp; &nbsp; &nbsp;<b>Endereço:</b> Rua Comendador Vianna, 64 - Centro, Sabará<br><br>
            &nbsp; &nbsp; &nbsp;Avalie o profissional: <br>
            <form id="avaliacao-forms" action="conexaobd6.php" method="POST">
            &nbsp; &nbsp; &nbsp;<div class="rating">
                <input type="radio" id="star5" name="rating" value="5">
                <label for="star5">&#9733;</label>
                <input type="radio" id="star4" name="rating" value="4">
                <label for="star4">&#9733;</label>
                <input type="radio" id="star3" name="rating" value="3">
                <label for="star3">&#9733;</label>
                <input type="radio" id="star2" name="rating" value="2">
                <label for="star2">&#9733;</label>
                <input type="radio" id="star1" name="rating" value="1">
                <label for="star1">&#9733;</label>
            </div>
            <button type="submit">Enviar Avaliação</button> <br><br>
           
        </form>

        <p id="mensagem"></p>
        <h2>Média Atual: <span id="avaliacao">Carregando...</span></h2>
    </div>
        
    <script>
    let isFormSubmitted = false;  

    document.getElementById('avaliacao-forms').addEventListener('submit', function(event) {
       
        event.preventDefault();

        
        if (isFormSubmitted) {
            return;
        }

        
        isFormSubmitted = true;

        
        const submitButton = document.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.innerText = "Enviado.";  

        let formData = new FormData(this);
        fetch('conexaobd6.php', {
            method: 'POST',
            body: formData
        }).then(response => response.json())
          .then(data => {
                if (data.success) {
                    document.getElementById('mensagem').innerText = 'Obrigado pela avaliação!';
                    document.getElementById('avaliacao').innerText = data.media;
                } else {
                    document.getElementById('mensagem').innerText = 'Erro ao salvar a avaliação. Tente novamente mais tarde.';
                }
          }).catch(error => {
              document.getElementById('mensagem').innerText = 'Ocorreu um erro. Tente novamente.';
          });
    });
</script>

    <footer class="corrd">
    <div class="corrd_copy">
        <p>TecMind 2024 -

           <!-- link instagram-->
            <a href="https://www.instagram.com/_tecmind/">    
             <img  id="insta" src="../img/insta.png" alt="">
            </a>
        </p>    

    </div>

</body>
</html>