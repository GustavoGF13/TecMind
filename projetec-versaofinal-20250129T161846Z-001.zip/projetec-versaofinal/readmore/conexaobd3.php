<?php

$servidor = "localhost";
$usuario = "root";
$senhaser = "";
$bd = "projetec"; 

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

   
   if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["rating"])) {
    $avaliacao = intval($_POST["rating"]);


$sql = "INSERT INTO Avaliacoes3 (avaliacao) VALUES (?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $avaliacao);

if ($stmt->execute()) {
    
    $result = $conn->query("SELECT AVG(avaliacao) AS media FROM Avaliacoes3");
    $row = $result->fetch_assoc();
    $media = round($row['media'], 2);

    echo json_encode(["success" => true, "media" => $media]);
} else {
    echo json_encode(["error" => "Erro ao salvar a avaliação"]);
}

$stmt->close();
} else {
echo json_encode(["error" => "Nenhuma avaliação enviada"]);
}

$conn->close();
?>