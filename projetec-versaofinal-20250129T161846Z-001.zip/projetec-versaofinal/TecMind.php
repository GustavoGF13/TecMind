<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="pagina.css">
    <link rel="stylesheet" href="paginicial.css">
    <title>TecMind</title>

</head>

<body>

    <header class="back_fundo">

        
        <a href="TecMind.php">
            <img src="img/logo.png" alt="" class="logo">
        </a>
        <div class="nome_site">
            <h1 id="tecmind">Tec<span class="cor_blog">Mind</span> </h1>

        </div>

        <ul>
           
            <a href="quemsomos.html" target="_self">
                <li class="option">Quem somos? </li>
            </a>
            <a href="obrigado.html" target="_self">
                <li class="option">Fale Conosco</li>
            </a>

            <a href="login.php" target="_self">
                <img src="img/icons.png" alt="" class="icons"> &nbsp;
            </a>
        </ul>

    </header>

    <?php

$servidor = "localhost";
$usuario = "root";
$senhaser = "";
$bd = "projetec";  

echo "<style>
            td {
                
                border-radius: 10px;
                width: 109px;
                height: 44px;
                background-color: rgb(249 249 249 / 99%);
                margin-left: 1%;
                border-color: rgb(255, 255, 255);
                border-radius: 10px;

            }
                table{
                position: relative;
                top:746px;
                left: 12px;
                background-color: rgb(203 199 199 / 99%);
                border-top: 8px solid rgb(223 223 223 / 99%);
                border-left: 8px solid rgb(223 223 223 / 99%);
                border-bottom: 8px solid rgb(223 223 223 / 99%);
                border-right: 8px solid rgb(223 223 223 / 99%);}
}
                </style>";

$conn = new mysqli($servidor, $usuario, $senhaser, $bd);
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$abordagem = isset($_GET['Abordagem']) ? $_GET['Abordagem'] : '';
$sexo = isset($_GET['Sexo']) ? $_GET['Sexo'] : '';
$tipo_consulta = isset($_GET['TipoConsulta']) ? $_GET['TipoConsulta'] : '';


if (($abordagem && $sexo) || ($abordagem && $tipo_consulta) || ($sexo && $tipo_consulta)) {
    echo "<p style='color: red;'>Só é possível realizar a pesquisa utilizando um parâmetro por vez. Por favor, escolha entre abordagem, sexo ou tipo de consulta.</p>";
} else {
    
    $sql = "SELECT * FROM profissional WHERE 1";

    $parametros = [];
    $tipo = '';

    if (!empty($abordagem)) {
        $sql = "SELECT * FROM profissional WHERE Abordagem LIKE ?";
        $parametros[] = "%" . $abordagem . "%";
        $tipo = 's'; // Tipo string
    } elseif (!empty($sexo)) {
        $sql = "SELECT * FROM profissional WHERE Sexo LIKE ?";
        $parametros[] = "%" . $sexo . "%";
        $tipo = 's'; 
    } elseif (!empty($tipo_consulta)) {
        $sql = "SELECT * FROM profissional WHERE Consulta LIKE ?";
        $parametros[] = "%" . $tipo_consulta . "%";
        $tipo = 's'; 
    }

   
    $stmt = $conn->prepare($sql);


    if (!empty($parametros)) {
        $stmt->bind_param($tipo, ...$parametros);
    }

    
    $stmt->execute();
    
    $resultado = $stmt->get_result();

    
    if ($resultado->num_rows > 0) {
        
        echo "<table border='1'>
                 <tr>
                     
                     <th>Nome</th>
                     <th>Abordagem</th>
                     <th>Sexo</th>
                     <th>Endereço</th>
                     <th>Tipo de Consulta</th>
                     <th>Email para contato</th>
                 </tr>";

        
        while ($row = $resultado->fetch_assoc()) {
            
            $endereco = $row['Rua'] . ", " . $row['Numero'] . " - " . $row['Bairro'];

            echo "<tr>
                     
                     <td>" . htmlspecialchars($row['Nome']) . "</td>
                     <td>" . htmlspecialchars($row['Abordagem']) . "</td>
                     <td>" . htmlspecialchars($row['Sexo']) . "</td>
                     <td>" . htmlspecialchars($endereco) . "</td>
                     <td>" . htmlspecialchars($row['Consulta']) . "</td>
                     <td>" . htmlspecialchars($row['Email']) . "</td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "Nenhum psicólogo encontrado.";
    }

    // Fecha a conexão
    $stmt->close();
    $conn->close();
}
?>

<fieldset class="tamanho1" >

    <h1 class="colorh1">&nbsp;&nbsp;&nbsp;Busque Seu Psicólogo</h1>
    <br>

    <hr class="linha"> <br>

    <form method="get" action="">
        
        <label  for="Abordagem"><h2 class="color">&nbsp;&nbsp;&nbsp;&nbsp;Abordagem:</h2></label><br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

        <select type="text" id="Abordagem" name="Abordagem" value="<?php echo htmlspecialchars($abordagem); ?>">
        <option value="">Selecione</option>
            <option value="Abordagem centrada na pessoa" <?php echo ($abordagem == 'Abordagem centrada na pessoa') ? 'selected' : ''; ?>>Abordagem centrada na pessoa</option>
            <option value="Análise bioenergética" <?php echo ($abordagem == 'Análise bioenergética') ? 'selected' : ''; ?>>Análise bioenergética</option>
            <option value="Behavorismo" <?php echo ($abordagem == 'Behavorismo') ? 'selected' : ''; ?>>Behavorismo</option>
            <option value="Fenomenologia" <?php echo ($abordagem == 'Fenomenolgia') ? 'selected' : ''; ?>>Fenomenologia</option>
            <option value="Gestalt-Terapia" <?php echo ($abordagem == 'Gestalt-Terapia') ? 'selected' : ''; ?>>Gestalt-Terapia</option>
            <option value="Psicanálise" <?php echo ($abordagem == 'Psicanálise') ? 'selected' : ''; ?>>Psicanálise</option>
            <option value="Psicodinâmica" <?php echo ($abordagem == 'Psicodinâmica') ? 'selected' : ''; ?>>Psicodinâmica</option>
            <option value="Psicodrama" <?php echo ($abordagem == 'Psicodrama') ? 'selected' : ''; ?>>Psicodrama</option>
            <option value="Psicologia Analítica Junguiana" <?php echo ($abordagem == 'Psicologia Analítica Junguiana') ? 'selected' : ''; ?>>Psicologia Analítica Junguiana</option>
            <option value="Terapia Cognitivo Comportamental" <?php echo ($abordagem == 'Terapia Cognitivo Comportamental') ? 'selected' : ''; ?>>Terapia Cognitivo Comportamental</option>
            </select><br><br>

        <hr class="linha"> <br>
    
        <label for="Sexo"> <h2 class="color">&nbsp;&nbsp;&nbsp; Sexo do psicólogo:</h2></label><br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select id="Sexo" name="Sexo">
            <option value="">Selecione</option>
            <option value="masculino" <?php echo ($sexo == 'masculino') ? 'selected' : ''; ?>>Masculino</option>
            <option value="feminino" <?php echo ($sexo == 'feminino') ? 'selected' : ''; ?>>Feminino</option>
        </select><br><br>

        <hr class="linha"> <br>
    
        <label for="TipoConsulta"> <h2 class="color">&nbsp;&nbsp;&nbsp;&nbsp;Tipo de Consulta:</h2></label><br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select id="TipoConsulta" name="TipoConsulta">
            <option value="">Selecione</option>
            <option value="online" <?php echo ($tipo_consulta == 'online') ? 'selected' : ''; ?>>Online</option>
            <option value="presencial" <?php echo ($tipo_consulta == 'presencial') ? 'selected' : ''; ?>>Presencial</option>
        </select><br><br>

        <hr class="linha"> <br>
    
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Pesquisar">

    </form><br>

</fieldset>


        

    <!--área das imagens-->
    <div class="panel">

        <div class="card">
            <div class="img-box">
                <img src="img/foto1.png">
            </div>
            <div class="content">
                <h2 class="rm_h1">Dra. Renata Santos</h2>
                <p class=""><b>Sexo: </b>Feminino <br>
                    <b>Abordagem:</b> Psicanálise <br>
                    Avenida Miguel Perrela, 692 - Castelo, Belo Horizonte
                </p>
                <a href="readmore/readmore1.php" class="read-more">
                    Ler Mais
                </a>
            </div>
        </div>
    
        <div class="card">
            <div class="img-box">
                <img src="img/teste5.png">
            </div>
            <div class="content">
                <h2 class="rm_h1">Dr. Gabriel Torres</h2>
                <p> <b>Sexo:</b> Masculino <br>
                    <b>Abordagem:</b> Gestalt-terapia <br>
                    Rua Volta Redonda, 96 - Vila Santa Cruz, Sabará
                </p>
                <a href="readmore/readmore2.php" class="read-more" target="_self">
                Ler Mais
                </a>
            </div>
        </div>
    
        <div class="card">
            <div class="img-box">
                <img src="img/teste3.png">
            </div>
            <div class="content">
                <h2 class="rm_h1" >Dra. Beatriz Pereira</h2>
                <p><b>Sexo:</b> Feminino <br>
                    <b>Abordagem: </b>Psicodinâmica <br>
                    Av. dos Andradas, 3323 - Centro, Belo Horizonte 
                </p>
                <a href="readmore/readmore3.php" class="read-more">
                Ler Mais
                </a>
            </div>
        </div>

        <div class="card">
            <div class="img-box">
                <img src="img/foto4.png">
            </div>
            <div class="content">
                <h2 class="rm_h1">Dr. Rodrigo Almeida</h2>
                <p><b>Sexo:</b> Masculino<br>
                    <b>Abordagem: </b>Terapia comportamental <br>
                    Av. Pref. Serafim Mota Barros, 65 - Centro, Sabará
                </p>
                <a href="readmore/readmore4.php" class="read-more">
                Ler Mais
                </a><br>
            </div>
        </div>
    
        <div class="card">
            <div class="img-box">
                <img src="img/foto5.png">
            </div>
            <div class="content">
                <h2 class="rm_h1">Dra. Camila Santos</h2>
                <p> <b>Sexo:</b> Feminino <br>
                    <b>Abordagem:</b> Behavorismo <br>
                    Comendador Viana, 89 - Centro, Sabará
                </p>
                <a href="readmore/readmore5.php" class="read-more" target="_self">
                Ler Mais
                </a>
            </div>
        </div>
    
        <div class="card">
            <div class="img-box">
                <img src="img/foto6.png">
            </div>
            <div class="content">
                <h2 class="rm_h1">Dr. Pedro Júnior</h2>
                <p><b>Sexo: </b>Masculino <br>
                    <b>Abordagem:</b> Fenomenologia <br>
                    Rua Dr. Álvaro Camargos, 345 - Venda Nova, Belo Horizonte
                </p>
                <a href="readmore/readmore6.php" class="read-more">
                Ler Mais
                </a>
            </div>
        </div>
    </div>
    
    <footer class="corrd">
    <div class="corrd_copy2">
        <p>TecMind 2024 -

           <!-- link instagram-->
            <a href="https://www.instagram.com/_tecmind/">    
             <img  id="insta" src="img/insta.png" alt="">
            </a>
        </p>    

    </div>
</footer>

</body>


</html>