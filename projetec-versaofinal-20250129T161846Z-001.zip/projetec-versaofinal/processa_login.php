<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servidor = "localhost";
    $usuario = "root";
    $senhaser = "";
    $bd = "projetec"; 
    
    
    $conn = new mysqli($servidor, $usuario, $senhaser, $bd);
    
    
    if ($conn->connect_error) {
        die("Falha na conexão: " . $conn->connect_error);
    }
    
    $email = isset($_POST["email"]) ? $_POST["email"] : null;
    $senha = isset($_POST["senha"]) ? $_POST["senha"] : null;

    
    if (!$email || !$senha) {
        echo "Por favor, preencha todos os campos.";
        exit();
    }

    
    $email = $conn->real_escape_string($email);

    
    $sql = "SELECT * FROM usuario WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        
        $row = $result->fetch_assoc();

        
        if ($senha === $row["Senha"]) {
            $_SESSION['email'] = $email;
            echo "<br><br<b><p> Bem-vindo, </p></b>" . "<b><p>" . $_SESSION['email'] . "</p></b>" ; 
            exit();
        }
    } else {
        
        $sql2 = "SELECT * FROM profissional WHERE email = '$email'";
        $result2 = $conn->query($sql2);

        if ($result2->num_rows > 0) {
            
            $row2 = $result2->fetch_assoc();

            
            if ($senha === $row2["Senha"]) {
                $_SESSION['email'] = $email;
                echo "<br><br<b><p> Bem-vindo, </p></b>" . "<b><p>" . $_SESSION['email'] . "</p></b>" ; 
                exit();
            } else {
                echo "<br><br><b><p>Senha incorreta.</p></b>"; 
            }
        } else {
            echo "<br><br><b><p>Usuário não encontrado</p></b>"; 
        }
    }
    $conn->close();
}

?>