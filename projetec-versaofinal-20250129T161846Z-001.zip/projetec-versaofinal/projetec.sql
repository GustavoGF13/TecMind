-- drop database projetec;

create database if not exists projetec;
use projetec;

create table if not exists usuario(
CPF varchar(14),
Nome varchar(40) not null,
Sexo varchar (12) not null,
Email varchar(50) not null,
Senha varchar(20) not null,
DtNasc date, -- ano,mes,dia,
Cidade varchar(40) not null,
primary key(CPF)
);

create table if not exists profissional(
CRP varchar(5),
Nome varchar(40) not null,
Email varchar(50) not null,
Senha varchar (25) not null,
Sexo varchar(9) not null,
Abordagem varchar(30) not null,
Rua varchar(40) not null,
Numero varchar(5) not null,
Bairro varchar(50) not null,
Consulta varchar(50) not null,
Foto BLOB,
primary key(CRP)
);

create table if not exists acessa(
CPF int(14),
CRP varchar(5),
primary key(CPF, CRP),
foreign key(CPF) references usuario(CPF),
foreign key(CRP) references profissional(CRP)
);

select * from usuario;

CREATE TABLE if not exists Avaliacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    avaliacao INT NOT NULL,
    data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE if not exists Avaliacoes2 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    avaliacao INT NOT NULL,
    data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE if not exists Avaliacoes3 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    avaliacao INT NOT NULL,
    data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE if not exists Avaliacoes4 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    avaliacao INT NOT NULL,
    data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE if not exists Avaliacoes5 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    avaliacao INT NOT NULL,
    data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE if not exists Avaliacoes6 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    avaliacao INT NOT NULL,
    data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
